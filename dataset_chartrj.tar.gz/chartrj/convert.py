import scipy.io
import numpy as np
import sys

# http://archive.ics.uci.edu/ml/datasets/Character+Trajectories
'''
Each character sample is a 3-dimensional pen tip velocity trajectory. This is 
contained in matrix format, with 3 rows and T columns where T is the length of 
the character sample.
'''

header = 'cat(0) reset(1) x(2) y(3) z(4)'
fmt    = '%2d    %2d    % 4.3f % 4.3f % 4.3f'

dst_file='data.txt'
PLOT = False
mat = scipy.io.loadmat('mixoutALL_shifted.mat')
#mat.keys() => ['mixout', '__version__', '__header__', 'consts', '__globals__']

consts = mat['consts'][0][0]
cat = consts[4][0]
#array con tutte le cat lungo 2858

#dati: array bidimensionale 3x2858
mixout = mat['mixout'][0]
print mixout.shape #(, 2858) = ho 2858 ripetizioni

#ogni ripetizione ha 3 righe e colonne variabili
print mixout[0].shape #(3, 178)



if PLOT:
    from mpl_toolkits.mplot3d import Axes3D
    import pylab as plt
    for i in range(0,len(mixout),25):
        print mixout[i].shape #(3, 178)
        
        d = mixout[i]

        fig = plt.figure()
        fig.suptitle(str(i) + ') Category ' + str(cat[i]))
        ax = fig.add_subplot(211, projection='3d')
        ax.plot(d[0][:], d[1][:], d[2][:])
        
        ax1 = fig.add_subplot(614)
        ax1.plot(d[0][:])
        ax2 = fig.add_subplot(615)
        ax2.plot(d[1][:])
        ax3 = fig.add_subplot(616)
        ax3.plot(d[2][:])

        plt.show()
        plt.close()
    
    sys.exit()
        

print 'converting data...'
outdata = np.empty((0,5))
for i in range(len(mixout)):
    #print mixout[i].shape #(3, 178)
    
    l = mixout[i].shape[1]
    
    c = np.zeros((l,1)) + cat[i]
    r = np.zeros((l,1))
    r[0] = 1
    
    #print c.shape, '----', r.shape, '----', mixout[i].T.shape
    d = np.hstack((c,r,mixout[i].T))
    
    #print 'USCITA:', d.shape
    
    outdata = np.vstack((outdata,d))
    
    #print 'outdata:', outdata.shape


with open(dst_file, 'w') as outFile:
    outFile.write(header+'\n')
    np.savetxt(outFile, outdata, fmt=fmt)
print 'Done!'

