import numpy as np
import sys

'''
http://archive.ics.uci.edu/ml/datasets/Character+Trajectories

- trimma i dati eliminando le parti a 0 all'inizio e alla fine
- crea un dataset secondo le indicazioni all'inziio. le "rep" indiicate sono quelle del train. 
  il test e' composto dalle stesse ripetizioni prendendo le successive
'''

infile = 'data.txt'

configs = {}
configs['2cat20rep'] = {'cat_min':0, 'cat_max':2, 'rep':20}
configs['2cat30rep'] = {'cat_min':0, 'cat_max':2, 'rep':30}
configs['4cat30rep'] = {'cat_min':0, 'cat_max':4, 'rep':30}
configs['8cat30rep'] = {'cat_min':0, 'cat_max':8, 'rep':30}

header = 'cat(0) reset(1) x(2) y(3) z(4)'
fmt    = '%2d    %2d    % 4.3f % 4.3f % 4.3f'
   

print 'Loading data from ', infile, '....'
data = np.loadtxt(infile,skiprows=1)

print 'loaded: ', data.shape
print "CATEGORIE: ", np.unique(data[:,0])
print '******************'


def slices_from_resets_with_cat(cat,reset):
    """
    Receives an array composed of 0s and 1s and returns the slices contained
    between 1s
    """
    resets = np.argwhere(reset).ravel()
    # Computes the slices for each repetition
    repetition_slices = {}
    begin = 0
    for r in resets:
        if r == begin:
            continue
        
        c = cat[begin]
        if not repetition_slices.has_key(c):
            repetition_slices[c] = []
            
        repetition_slices[c].append(slice(begin, r))
        begin = r
    
    c = cat[begin]
    if not repetition_slices.has_key(c):
        repetition_slices[c] = []
    repetition_slices[c].append(slice(begin, len(reset)))
    
    return repetition_slices



slices = slices_from_resets_with_cat(data[:,0],data[:,1])

for fid in configs.keys():
    config = configs[fid]
    outfile_train = 'chartrj_' + fid + '_train.txt'
    outfile_test  = 'chartrj_' + fid + '_test.txt'
    
    print '+++++++++++++++ config ', fid
    print '+++++++++++++++ ', outfile_train, outfile_test
     
    #configs['8cat30rep'] = {'cat_min':0, 'cat_max':8, 'rep':30}

    data_train = np.empty((0,5)) #prime 60
    data_test  = np.empty((0,5)) #successive 59

    for cat in slices:
        if cat < config['cat_min'] or cat > config['cat_max']:
            continue 
            
        print '***********', cat, len(slices[cat])
        
        for i, s in enumerate(slices[cat]):
            #print '\t', i,s
            
            
            d = data[s]
            
            #trovo inizio e fine piatti
            start_i = 0
            while (d[start_i,2]==0 and d[start_i,3]==0 and d[start_i,4]==0):
                start_i+=1
            start_i-=1
            
            end_i = d.shape[0]-1
            while (d[end_i,2]==0 and d[end_i,3]==0 and d[end_i,4]==0):
                end_i-=1
            end_i+=1
            
            s2 = slice(s.start + start_i, s.start + end_i+1)
            
            data_trimmed = data[s2]
            data_trimmed[0,1] = 1 #reset!
            
            
            if i < config['rep']:
                data_train = np.vstack((data_train,data_trimmed))
            elif i < config['rep'] + config['rep']:
                data_test = np.vstack((data_test,data_trimmed))
        
    print 'saving', outfile_train
    with open(outfile_train, 'w') as outFile:
        outFile.write(header+'\n')
        np.savetxt(outFile, data_train, fmt=fmt)

    print 'saving', outfile_test
    with open(outfile_test, 'w') as outFile:
        outFile.write(header+'\n')
        np.savetxt(outFile, data_test, fmt=fmt)
